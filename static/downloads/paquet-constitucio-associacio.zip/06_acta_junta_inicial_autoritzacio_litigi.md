# ACTA DE LA JUNTA DIRECTIVA INICIAL

## Autorització de l’actuació urbanística i judicial

**Associació Comunitària Rec Comtal – Benet Corner**  
**Data:** [DATA]  
**Lloc o mitjà:** [LLOC/REUNIÓ TELEMÀTICA]  
**Hora:** [HORA]

### Assistents

- [NOM], president/a
- [NOM], secretari/ària
- [NOM], tresorer/a
- [ALTRES]

La Junta queda vàlidament constituïda d’acord amb els estatuts.

### Antecedents

1. L’Ajuntament de Barcelona ha aprovat definitivament el **Pla de millora urbana per a la regulació de l’edifici d’habitatges de protecció oficial situat al carrer del Rec Comtal 19B**, expedient **26PL17180**.
2. L’acord consta publicat al BOPB el **8 de juliol de 2026** i el mateix anunci indica la possibilitat d’interposar recurs contenciós administratiu davant la Sala Contenciosa Administrativa del Tribunal Superior de Justícia de Catalunya.
3. L’associació té entre les seves finalitats la protecció de Benet Corner, el verd urbà, el Rec Comtal, el patrimoni arqueològic, la participació ciutadana i els interessos col·lectius relacionats.
4. La Junta ha de decidir una actuació informada i professional, sense afirmar com a fets qüestions que no hagin estat verificades.

### Acords

La Junta acorda:

1. Autoritzar la preparació i, si l’advocat/ada ho considera jurídicament viable i dins del termini, la interposició d’un recurs contenciós administratiu contra l’acord d’aprovació definitiva identificat anteriorment.
2. Autoritzar que el recurs inclogui, si és procedent, una sol·licitud separada o conjunta de mesures cautelars, especialment per evitar actuacions materials que puguin fer irreversible el dany mentre es tramita el procediment.
3. Designar com a direcció lletrada **[NOM I COL·LEGIACIÓ DE L’ADVOCAT/ADA]**, subjecte a l’acceptació del pressupost i de l’encàrrec professional.
4. Designar com a representació processal **[NOM I COL·LEGIACIÓ DEL/DE LA PROCURADOR/A]**, subjecte a l’acceptació del pressupost i de l’encàrrec professional.
5. Facultar la Presidència per signar l’encàrrec professional, atorgar poder notarial o apoderament apud acta, aportar documents i donar instruccions ordinàries, dins del pressupost aprovat.
6. Facultar la Secretaria per expedir certificacions d’aquesta acta i de la constitució de l’associació.
7. Establir un pressupost màxim inicial de **[IMPORT] euros, més IVA i despeses**, amb les partides separades següents:

   - assessorament i interposició: [IMPORT];
   - tramitació ordinària: [IMPORT];
   - procurador/a: [IMPORT];
   - mesures cautelars: [IMPORT];
   - informes tècnics: [IMPORT];
   - taxa judicial, si escau: [IMPORT];
   - reserva per costes adverses: [IMPORT].

8. Requerir que cap desistiment, transacció, renúncia, ampliació substancial de pretensions o compromís econòmic extraordinari es faci sense un nou acord de la Junta i, quan correspongui, de l’Assemblea.
9. Autoritzar la incorporació de persones físiques co-claimants només després que l’advocat/ada n’hagi valorat la legitimació, el consentiment informat, el risc de costes i la compatibilitat amb l’estratègia.
10. Ordenar que l’expedient intern contingui la publicació del BOPB, el text complet del pla, el comprovant de termini, els pressupostos professionals, els conflictes d’interès i les proves d’activitat comunitària.
11. Aprovar com a línia pública que l’associació defensa una solució compatible amb l’habitatge públic, la preservació del jardí, els usos comunitaris i la protecció del Rec Comtal. No s’han de publicar acusacions no verificades ni instruccions jurídiques reservades.

### Certificació

La Secretaria certifica que aquesta acta reflecteix l’acord adoptat per la Junta en la data indicada.

**El/la president/a**  
Nom: [NOM]  
Signatura: ______________________________

**El/la secretari/ària**  
Nom: [NOM]  
Signatura: ______________________________

