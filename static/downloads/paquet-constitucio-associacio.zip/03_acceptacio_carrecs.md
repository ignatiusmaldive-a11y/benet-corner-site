# ACCEPTACIÓ DELS CÀRRECS DE LA JUNTA DIRECTIVA

## Associació Comunitària Rec Comtal – Benet Corner

Les persones que signem acceptem el càrrec indicat, declarem que no ens consta cap incompatibilitat legal per exercir-lo i ens comprometem a actuar d’acord amb els estatuts, la normativa aplicable, els acords associatius i els principis de transparència, diligència, confidencialitat i protecció de dades.

| Càrrec | Nom i cognoms | DNI/NIE | Acceptació i signatura | Data |
|---|---|---|---|---|
| President/a | [NOM] | [DOCUMENT] | __________________ | [DATA] |
| Secretari/ària | [NOM] | [DOCUMENT] | __________________ | [DATA] |
| Tresorer/a | [NOM] | [DOCUMENT] | __________________ | [DATA] |
| Vocal | [NOM, si escau] | [DOCUMENT] | __________________ | [DATA] |

### Declaració de conflictes d’interès

Cada persona signant declara:

- [ ] que no té cap conflicte d’interès conegut amb l’assumpte Benet Corner que impedeixi exercir el càrrec;
- [ ] que informarà la Junta abans de participar en una decisió en què tingui un interès personal, professional o econòmic;
- [ ] que no utilitzarà informació reservada per a finalitats alienes a l’associació.

