# INFORMACIÓ I CONSENTIMENT DE PROTECCIÓ DE DADES

## Associació Comunitària Rec Comtal – Benet Corner

**Responsable:** Associació Comunitària Rec Comtal – Benet Corner, en constitució, amb domicili a **[ADREÇA]**.  
**Contacte:** [CORREU DE L’ASSOCIACIÓ]  
**Finalitats:** gestionar l’adhesió, convocar reunions, administrar quotes, coordinar voluntariat i activitats, informar de projectes, mantenir els llibres associatius, complir obligacions legals i preparar actuacions de participació pública o defensa dels interessos de l’associació.

Les dades es tractaran amb accés limitat i no es publicaran sense una base legal i, quan calgui, consentiment específic. Les dades d’infants, salut, imatges i qualsevol informació especialment sensible requereixen mesures i autoritzacions específiques.

Les dades es conservaran mentre existeixi la relació associativa i durant els terminis legals aplicables. La persona interessada pot exercir els drets d’accés, rectificació, supressió, oposició, limitació i portabilitat quan correspongui, adreçant-se a **[CORREU/ADREÇA]**, i pot reclamar davant l’Autoritat Catalana de Protecció de Dades o l’autoritat competent.

### Declaració de la persona interessada

Nom i cognoms: **[NOM]**  
DNI/NIE: **[DOCUMENT]**  
Correu: **[CORREU]**  

Marcant les opcions següents:

- [ ] accepto el tractament de les meves dades per gestionar la meva condició de persona associada;
- [ ] accepto rebre convocatòries i informació de l’associació per correu electrònic o missatgeria;
- [ ] accepto participar en activitats i comunicacions internes segons les finalitats descrites;
- [ ] accepto que les meves dades de contacte siguin accessibles a la Junta i a les persones estrictament necessàries per a la coordinació;
- [ ] **no** autoritzo l’ús públic del meu nom, imatge, veu o testimoni. Qualsevol ús públic requerirà una autorització separada.

**Lloc i data:** [LLOC], [DATA]  
**Signatura:** ______________________________

