# Paquet de constitució — associació comunitària Rec Comtal / Benet Corner

**Estat:** esborrany per revisar i signar  
**Data de preparació:** 25 d’agost de 2026  
**Àmbit:** constitució d’una associació catalana sense ànim de lucre i preparació de la seva inscripció

## Ús d’aquest paquet

Aquest directori conté plantilles preparades a partir del pla urgent del projecte, els fets documentats sobre Benet Corner i els requisits orientatius del Registre d’Associacions de la Generalitat.

Abans de signar:

1. confirmar la denominació exacta i la seva disponibilitat registral;
2. completar totes les dades personals, domicili, dates i signatures;
3. fer revisar els estatuts per una persona amb experiència en dret associatiu català;
4. fer revisar especialment `06_acta_junta_inicial_autoritzacio_litigi.md` per l’advocat/ada i el/la procurador/a;
5. no publicar cap còpia amb DNI/NIE, adreces particulars, telèfons o signatures.

## Fitxers

- `01_acta_fundacional.md` — acord privat de constitució i designació de la Junta inicial.
- `02_estatuts.md` — estatuts adaptats a l’entitat comunitària i a la defensa urbanística, ambiental i patrimonial.
- `03_acceptacio_carrecs.md` — acceptació individual dels càrrecs de la Junta.
- `04_registre_inicial_socis.md` — registre intern inicial de persones associades.
- `05_consentiment_dades.md` — full de consentiment i informació bàsica de protecció de dades.
- `06_acta_junta_inicial_autoritzacio_litigi.md` — resolució específica sobre el recurs contenciós i els poders professionals.
- `07_checklist_constitucio.md` — seqüència pràctica de signatura, NIF, registre i arxiu.

## Denominació de treball

> **Associació Comunitària Rec Comtal – Benet Corner**

És una denominació de treball. No s’ha de signar ni presentar fins que es comprovi que és admissible i disponible. La denominació ha de ser exactament la mateixa a l’acta fundacional i als estatuts, i ha d’incloure el tipus jurídic “Associació” o “Assoc.”.

## Bases jurídiques de referència

- Llibre tercer del Codi civil de Catalunya, especialment els articles 321-1 a 321-6 i 322-1 i següents.
- Tràmit oficial de constitució d’una associació de la Generalitat de Catalunya.
- Article 45.2.d de la LJCA per a l’autorització de la persona jurídica per litigar.
- Article 23.2 de la LJCA: advocat/ada i procurador/a davant una Sala col·legiada.

Aquest paquet no substitueix assessorament jurídic. La constitució pot fer-se amb document privat, però el litigant ha de validar la capacitat processal, la representació i la resolució d’autorització abans de presentar el recurs.
