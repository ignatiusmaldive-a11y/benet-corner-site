# REGISTRE INICIAL DE PERSONES ASSOCIADES

## Associació Comunitària Rec Comtal – Benet Corner

**Document intern restringit.** No publicar. Guardar amb accés limitat a la Junta o a la persona responsable de secretaria.

El registre s’ha d’actualitzar quan hi hagi altes, baixes o canvis de dades. No cal incloure en documents públics dades d’identificació, domicilis o telèfons.

| Núm. | Nom i cognoms | DNI/NIE/passaport | Nacionalitat | Domicili | Correu/telèfon | Data d’alta | Quota | Consentiment dades | Data baixa/notes |
|---:|---|---|---|---|---|---|---|---|---|
| 1 | [NOM] | [DOCUMENT] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| 2 | [NOM] | [DOCUMENT] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| 3 | [NOM] | [DOCUMENT] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

### Camps addicionals recomanats per al dossier de legitimació

Aquests camps s’han de guardar en un annex restringit, separat del registre públic:

- relació amb Benet Corner o amb el Rec Comtal;
- ús habitual o participació en activitats;
- residència o localització respecte de l’espai;
- si accepta ser co-claimant en un procediment, en document separat;
- documents acreditatius aportats;
- data d’última revisió del consentiment.

